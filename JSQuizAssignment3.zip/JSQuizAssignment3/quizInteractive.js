// Questions and Answers
const questions = [
    {
      question: "Who is the all-time top scorer in FIFA World Cup history?",
      options: ["Lionel Messi", "Cristiano Ronaldo", "Pele", "Miroslav Klose"],
      answer: "Miroslav Klose",
      selected: null // Added selected property to store user's answer
    },
    {
      question: "Who is the all-time top scorer in FIFA?",
      options: ["Lionel Messi", "Cristiano Ronaldo", "Pele", "Miroslav Klose"],
      answer: "Cristiano Ronaldo",
      selected: null
    },
    {
      question: "Which country has won the most FIFA World Cup titles?",
      options: ["Brazil", "Germany", "Argentina", "Argentina"],
      answer: "Brazil",
      selected: null
    },
    {
      question: "Which football club has won the most English Premier League titles?",
      options: ["Manchester United", " Chelsea", "Liverpool", "Arsenal"],
      answer: "Manchester United",
      selected: null
    },
    {
      question: "What is the record number of goals scored by a single player in a FIFA World Cup tournament?",
      options: ["13", "16", "17", "15"],
      answer: "16",
      selected: null
    },
    {
      question: "Which stadium is the largest in terms of capacity in the world?",
      options: ["Camp Nou (Barcelona, Spain)", "Santiago Bernabéu Stadium (Madrid, Spain)", "Rose Bowl (Pasadena, USA)", "Rungrado 1st of May Stadium (Pyongyang, North Korea)"],
      answer: "Rungrado 1st of May Stadium (Pyongyang, North Korea)",
      selected: null
    },
    {
      question: "Which country hosted the first-ever FIFA World Cup?",
      options: ["Uruguay", "Brazil", "Italy", "France"],
      answer: "Uruguay",
      selected: null
    }
  ];
  
  // Fake Authentication
  let authenticated = true; // For testing purposes, set to true to automatically authenticate
  
  // DOM Elements
  const quizForm = document.getElementById('quiz-form');
  const questionElement = document.getElementById('question');
  const optionsElement = document.getElementById('options');
  const feedbackElement = document.getElementById('feedback');
  const nextButton = document.querySelector('button[type="submit"]');
  
  // Event Listener
  quizForm.addEventListener('submit', submitAnswer);
  
  // Start Quiz
  startQuiz();
  
  function startQuiz() {
    if (!authenticated) {
      feedbackElement.innerText = "Please log in to start the quiz.";
      return;
    }
    displayQuestion(0);
  }
  
  function displayQuestion(index) {
    const currentQuestion = questions[index];
    questionElement.innerText = currentQuestion.question;
    optionsElement.innerHTML = '';
  
    currentQuestion.options.forEach(option => {
      const li = document.createElement('li');
      li.innerText = option;
      li.addEventListener('click', (event) => {
        event.preventDefault(); // Prevent form submission
        checkAnswer(option, currentQuestion);
        nextButton.disabled = false; // Enable Next button after answer selection
      });
      optionsElement.appendChild(li);
    });
  }
  
  function checkAnswer(selected, question) {
    question.selected = selected; // Store the selected answer in the question object
  
    if (selected === question.answer) {
      feedbackElement.innerText = "Correct!";
      feedbackElement.style.color = "green";
    } else {
      feedbackElement.innerText = "Incorrect! The correct answer is: " + question.answer;
      feedbackElement.style.color = "red";
    }
  }
  
  function submitAnswer(event) {
    event.preventDefault();
    const currentIndex = questions.findIndex(q => q.selected === null); // Find the index of the next unanswered question
    if (currentIndex !== -1) {
      displayQuestion(currentIndex);
      nextButton.disabled = true; // Disable Next button after submitting answer
    } else {
      showScore();
    }
  }
  
  function showScore() {
    let score = 0;
    questions.forEach(question => {
      if (question.answer === question.selected) {
        score++;
      }
    });
    feedbackElement.innerText = "Quiz completed! Your score is: " + score + "/" + questions.length;
    feedbackElement.style.color = "black";
  }
  